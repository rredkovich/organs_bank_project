#TODO:
# test_refresh - self.populate called
# test_save - self.model.save called