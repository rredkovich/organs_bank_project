# from tests.test_app.base_model_fixtures import base_model



# def test_field_names(base_model):
#     fields = base_model.field_names
#     assert fields == ['acceptor_id']


def test_get_all():
    assert True


def test_get_details():
    assert True


def test_possible_choices():
    assert True


def test_save():
    assert True
