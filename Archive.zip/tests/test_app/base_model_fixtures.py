import pytest
#
# from app.models.base_model import BaseModel
# from tests.fixtures import acceptor_a_pos
#
# @pytest.fixture
# def base_model(acceptor_a_pos):
#     return BaseModel(acceptor_a_pos)

